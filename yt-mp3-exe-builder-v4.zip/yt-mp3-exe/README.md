# YouTube → MP3 Converter — EXE Builder

This folder contains everything needed to build a standalone Windows EXE
that anyone can run — no Python, no setup, no terminal required.

## How to build the EXE

1. Make sure Python is installed (https://python.org)
2. Double-click **BUILD.bat**
3. Wait ~2 minutes while it installs deps and bundles everything
4. Find your EXE at **dist\YouTube-to-MP3.exe**

That's it. Share that one file with anyone.

## What happens when someone runs the EXE

- First launch: automatically downloads ffmpeg (~70 MB, one time only)
- Shows a setup screen with a progress bar during the download
- Once ready, opens http://localhost:5000 in their browser
- Every launch after that opens instantly

## Files in this folder

- app.py          — Flask backend with ffmpeg auto-installer
- static/         — Frontend web UI
- yt-mp3.spec     — PyInstaller build config
- BUILD.bat       — Double-click to build the EXE

## Notes

- The EXE bundles Python, Flask, and yt-dlp inside it (~80 MB)
- ffmpeg is downloaded separately on first run and stored next to the EXE
- Downloads are saved to a "downloads" folder next to the EXE
- If yt-dlp stops working, rebuild with: pip install -U yt-dlp then BUILD.bat again
- For personal use with content you have the right to download
