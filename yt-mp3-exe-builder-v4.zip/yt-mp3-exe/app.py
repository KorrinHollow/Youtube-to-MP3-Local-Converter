import os
import sys
import uuid
import threading
import zipfile
import urllib.request
import webbrowser
import time
import shutil
from flask import Flask, request, jsonify, send_from_directory, send_file

# ── Path helpers ──────────────────────────────────────────────────────────────
def base_path():
    if getattr(sys, '_MEIPASS', None):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def resource_path(rel):
    if getattr(sys, '_MEIPASS', None):
        return os.path.join(sys._MEIPASS, rel)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), rel)

BASE         = base_path()
STATIC_DIR   = resource_path("static")
DOWNLOAD_DIR = os.path.join(BASE, "downloads")
FFMPEG_DIR   = os.path.join(BASE, "ffmpeg_bin")
FFMPEG_EXE   = os.path.join(FFMPEG_DIR, "ffmpeg.exe")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)
os.makedirs(FFMPEG_DIR,   exist_ok=True)

# ── ffmpeg auto-installer ─────────────────────────────────────────────────────
FFMPEG_URL = (
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"
    "ffmpeg-master-latest-win64-gpl.zip"
)

ffmpeg_status = {"state": "checking", "progress": 0, "message": "Checking for ffmpeg…"}

def find_ffmpeg():
    if os.path.exists(FFMPEG_EXE):
        return FFMPEG_EXE
    return shutil.which("ffmpeg")

def download_ffmpeg():
    global ffmpeg_status
    ffmpeg_status = {"state": "downloading", "progress": 0, "message": "Downloading ffmpeg (≈70 MB)…"}
    zip_path = os.path.join(FFMPEG_DIR, "ffmpeg.zip")
    try:
        def reporthook(count, block, total):
            if total > 0:
                pct = int(count * block * 100 / total)
                ffmpeg_status["progress"] = min(pct, 99)
                ffmpeg_status["message"] = f"Downloading ffmpeg… {min(pct,99)}%"
        urllib.request.urlretrieve(FFMPEG_URL, zip_path, reporthook)
        ffmpeg_status["message"] = "Extracting ffmpeg…"
        with zipfile.ZipFile(zip_path, "r") as z:
            for member in z.namelist():
                if member.endswith("ffmpeg.exe") or member.endswith("ffprobe.exe"):
                    fname = os.path.basename(member)
                    with z.open(member) as src, open(os.path.join(FFMPEG_DIR, fname), "wb") as dst:
                        dst.write(src.read())
        os.remove(zip_path)
        ffmpeg_status = {"state": "ready", "progress": 100, "message": "ffmpeg ready!"}
    except Exception as e:
        ffmpeg_status = {"state": "error", "progress": 0, "message": f"Failed to download ffmpeg: {e}"}

def ensure_ffmpeg():
    global ffmpeg_status
    if find_ffmpeg():
        ffmpeg_status = {"state": "ready", "progress": 100, "message": "ffmpeg ready!"}
    else:
        threading.Thread(target=download_ffmpeg, daemon=True).start()

# ── yt-dlp via Python API (works inside frozen EXE) ──────────────────────────
def run_conversion(job_id, url, quality, fmt):
    with jobs_lock:
        jobs[job_id]["status"] = "working"
        jobs[job_id]["progress"] = 5

    output_template = os.path.join(DOWNLOAD_DIR, f"{job_id}_%(title)s.%(ext)s")
    ffmpeg = find_ffmpeg()

    try:
        import yt_dlp

        class ProgressHook:
            def __call__(self, d):
                if d.get("status") == "downloading":
                    total = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
                    downloaded = d.get("downloaded_bytes", 0)
                    if total:
                        pct = int(downloaded * 70 / total) + 10
                        with jobs_lock:
                            jobs[job_id]["progress"] = min(pct, 80)

        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": output_template,
            "quiet": True,
            "no_warnings": True,
            "progress_hooks": [ProgressHook()],
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": fmt,
                "preferredquality": quality if fmt == "mp3" else "0",
            }],
        }
        if ffmpeg:
            ydl_opts["ffmpeg_location"] = os.path.dirname(ffmpeg)

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        found = next((f for f in os.listdir(DOWNLOAD_DIR) if f.startswith(job_id + "_")), None)
        if not found:
            raise RuntimeError("Output file not found after download")

        with jobs_lock:
            jobs[job_id].update({"status": "done", "progress": 100, "filename": found})

    except Exception as e:
        with jobs_lock:
            jobs[job_id].update({"status": "error", "error": str(e)})


# ── Browser heartbeat watchdog ────────────────────────────────────────────────
import datetime

last_heartbeat = datetime.datetime.now()
HEARTBEAT_TIMEOUT = 6  # seconds — browser sends ping every 3s

def watchdog():
    """Shut down the server if browser hasn't pinged in a while."""
    time.sleep(10)  # grace period on startup
    while True:
        time.sleep(2)
        elapsed = (datetime.datetime.now() - last_heartbeat).total_seconds()
        if elapsed > HEARTBEAT_TIMEOUT:
            print("Browser closed — shutting down.")
            os._exit(0)

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=STATIC_DIR)
jobs = {}
jobs_lock = threading.Lock()


@app.route("/")
def index():
    return send_file(os.path.join(STATIC_DIR, "index.html"))

@app.route("/api/heartbeat", methods=["POST"])
def heartbeat():
    global last_heartbeat
    last_heartbeat = datetime.datetime.now()
    return jsonify({"ok": True})

@app.route("/api/ffmpeg-status")
def ffmpeg_status_route():
    return jsonify(ffmpeg_status)

@app.route("/api/convert", methods=["POST"])
def convert():
    if ffmpeg_status["state"] != "ready":
        return jsonify({"error": "ffmpeg not ready yet, please wait"}), 503
    data = request.json
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "No URL"}), 400
    job_id = uuid.uuid4().hex[:12]
    with jobs_lock:
        jobs[job_id] = {"status": "queued", "progress": 0, "filename": None, "error": None, "url": url}
    threading.Thread(
        target=run_conversion,
        args=(job_id, url, str(data.get("quality", "192")), str(data.get("format", "mp3")).lower()),
        daemon=True
    ).start()
    return jsonify({"job_id": job_id})

@app.route("/api/status/<job_id>")
def status(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    return jsonify(job) if job else (jsonify({"error": "Not found"}), 404)

@app.route("/api/download/<job_id>")
def download(job_id):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job or job["status"] != "done" or not job["filename"]:
        return jsonify({"error": "Not ready"}), 404
    return send_from_directory(DOWNLOAD_DIR, job["filename"], as_attachment=True)

@app.route("/api/clear", methods=["POST"])
def clear_done():
    data = request.json or {}
    with jobs_lock:
        for jid in data.get("job_ids", []):
            job = jobs.pop(jid, None)
            if job and job.get("filename"):
                path = os.path.join(DOWNLOAD_DIR, job["filename"])
                if os.path.exists(path):
                    os.remove(path)
    return jsonify({"ok": True})


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n🎵 YouTube → MP3 Converter starting…")
    ensure_ffmpeg()
    threading.Thread(target=watchdog, daemon=True).start()
    def open_browser():
        time.sleep(1.5)
        webbrowser.open("http://localhost:5000")
    threading.Thread(target=open_browser, daemon=True).start()
    print("   Open http://localhost:5000 in your browser\n")
    app.run(host="0.0.0.0", port=5000, debug=False)
