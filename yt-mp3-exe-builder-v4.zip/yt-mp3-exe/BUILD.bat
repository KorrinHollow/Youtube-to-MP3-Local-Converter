@echo off
echo ============================================
echo  YouTube to MP3 - EXE Builder
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

echo [1/3] Installing Python dependencies...
pip install flask yt-dlp pyinstaller mutagen certifi websockets --quiet --no-warn-script-location

echo [2/3] Building EXE with PyInstaller...
python -m PyInstaller yt-mp3.spec --clean --noconfirm
if errorlevel 1 (
    echo ERROR: PyInstaller build failed.
    pause
    exit /b 1
)

echo [3/3] Done!
echo.
echo ============================================
echo  Your EXE is in the dist\ folder:
echo  dist\YouTube-to-MP3.exe
echo.
echo  Share that single file with anyone!
echo  First launch downloads ffmpeg automatically.
echo ============================================
echo.
pause
