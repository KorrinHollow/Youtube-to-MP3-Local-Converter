block_cipher = None

from PyInstaller.utils.hooks import collect_all, collect_submodules

yt_dlp_datas, yt_dlp_binaries, yt_dlp_hiddenimports = collect_all('yt_dlp')

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=yt_dlp_binaries,
    datas=[
        ('static', 'static'),
        *yt_dlp_datas,
    ],
    hiddenimports=[
        *yt_dlp_hiddenimports,
        *collect_submodules('yt_dlp'),
        'flask',
        'flask.templating',
        'jinja2',
        'jinja2.ext',
        'werkzeug',
        'werkzeug.serving',
        'werkzeug.debug',
        'websockets',
        'mutagen',
        'certifi',
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='YouTube-to-MP3',
    debug=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    target_arch=None,
)
